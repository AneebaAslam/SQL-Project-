WITH DailyInterest AS (
    SELECT
        customer_id,
        txn_date,
        txn_amount,
        txn_amount + (txn_amount * 0.06 * 1.0 / 365) AS future_value
    FROM customer_transactions
)
SELECT
    customer_id,
    txn_date,
    txn_amount,
    future_value
FROM DailyInterest
ORDER BY customer_id, txn_date;
