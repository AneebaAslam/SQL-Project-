



--1.	How many unique nodes are there on the Data Bank system? 

SELECT COUNT(DISTINCT node_id) AS unique_node_count FROM customer_nodes;


--2.	What is the number of nodes per region? 
SELECT region_id, COUNT(DISTINCT node_id) AS node_count
FROM customer_nodes
GROUP BY region_id;

--3.	

SELECT r.*, b.customer_count FROM regions r 
JOIN (SELECT region_id, COUNT(DISTINCT customer_id) AS customer_count
FROM customer_nodes
GROUP BY region_id) b on r.region_id = b.region_id;

--4.	

SELECT 
  AVG(julianday(next_start_date) - julianday(start_date)) AS average_reallocation_days
FROM (
  SELECT 
    customer_id,
    node_id,
    start_date,
    LEAD(start_date) OVER (PARTITION BY customer_id ORDER BY start_date) AS next_start_date
  FROM customer_nodes
) AS Reallocations
WHERE next_start_date IS NOT NULL;


--5.	

WITH RankedReallocations AS (
  SELECT
    cn.region_id,
    cn.customer_id,
    julianday(cn.end_date) - julianday(cn.start_date) AS reallocation_days,
    ROW_NUMBER() OVER (PARTITION BY cn.region_id ORDER BY julianday(cn.end_date) - julianday(cn.start_date)) AS rn,
    COUNT(*) OVER (PARTITION BY cn.region_id) AS total
  FROM customer_nodes cn
),
Percentiles AS (
  SELECT
    region_id,
    MAX(CASE WHEN rn = ROUND(total * 0.5) THEN reallocation_days END) AS Median,
    MAX(CASE WHEN rn = ROUND(total * 0.8) THEN reallocation_days END) AS P80,
    MAX(CASE WHEN rn = ROUND(total * 0.95) THEN reallocation_days END) AS P95
  FROM RankedReallocations
  GROUP BY region_id
)
SELECT * FROM Percentiles;


