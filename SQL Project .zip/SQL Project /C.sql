
--C.	Data Allocation Challenge
 
--1. Running Customer Balance Column
   
 
   SELECT customer_id, txn_date,
          SUM(txn_amount) OVER (PARTITION BY customer_id ORDER BY txn_date 
          ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as running_balance
   FROM customer_transactions;
 

--2. Customer Balance at the End of Each Month**: Aggregate the running balances to get the last entry for each month for each customer.

WITH MonthlyBalances AS (
    SELECT 
        customer_id, 
        strftime('%Y-%m', txn_date) AS month,
        LAST_VALUE(SUM(txn_amount)) OVER (PARTITION BY customer_id, strftime('%Y-%m', txn_date) ORDER BY txn_date 
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as end_of_month_balance
    FROM customer_transactions
    GROUP BY customer_id, month
)
SELECT 
    customer_id, 
    month, 
    MAX(end_of_month_balance) AS end_of_month_balance
FROM MonthlyBalances
GROUP BY customer_id, month;


--3. Minimum, Average, and Maximum Values of the Running Balance for Each Customer
WITH RunningBalances AS (
    SELECT 
        customer_id, 
        SUM(txn_amount) OVER (PARTITION BY customer_id ORDER BY txn_date 
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as running_balance
    FROM customer_transactions
)
SELECT 
    customer_id, 
    MIN(running_balance) as min_balance, 
    AVG(running_balance) as avg_balance, 
    MAX(running_balance) as max_balance
FROM RunningBalances
GROUP BY customer_id;


