
--B.	Customer Transactions
--1.
	
SELECT transaction_type, 
       COUNT(*) AS unique_count, 
       SUM(amount) AS total_amount
FROM transactions
GROUP BY transaction_type;

--2.	

SELECT AVG(deposit_count) AS average_deposit_count, 
       AVG(total_amount) AS average_total_amount
FROM (
  SELECT customer_id, 
         COUNT(*) AS deposit_count, 
         SUM(amount) AS total_amount
  FROM deposits
  GROUP BY customer_id
) AS customer_deposits;


--3.	

WITH MonthlyActivity AS (
  SELECT
    customer_id,
    strftime('%Y-%m', transaction_date) AS month,
    COUNT(CASE WHEN transaction_type = 'Deposit' THEN 1 END) AS deposit_count,
    COUNT(CASE WHEN transaction_type = 'Purchase' THEN 1 END) AS purchase_count,
    COUNT(CASE WHEN transaction_type = 'Withdrawal' THEN 1 END) AS withdrawal_count
  FROM transactions -- Assuming all transactions are in one table; adjust as necessary
  GROUP BY customer_id, month
)
SELECT
  month,
  COUNT(*) AS customers_meeting_criteria
FROM MonthlyActivity
WHERE deposit_count > 1 AND (purchase_count = 1 OR withdrawal_count = 1)
GROUP BY month;

--4.	

SELECT customer_id,
       strftime('%Y-%m', transaction_date) AS month,
       SUM(CASE WHEN transaction_type = 'Deposit' THEN amount
                WHEN transaction_type IN ('Withdrawal', 'Purchase') THEN -amount
                ELSE 0 END) AS closing_balance
FROM transactions
GROUP BY customer_id, month
ORDER BY customer_id, month;

--5.	
WITH MonthlyBalances AS (
  SELECT customer_id,
         strftime('%Y-%m', transaction_date) AS month,
         SUM(CASE WHEN transaction_type = 'Deposit' THEN amount
                  WHEN transaction_type IN ('Withdrawal', 'Purchase') THEN -amount
                  ELSE 0 END) AS balance
  FROM transactions
  GROUP BY customer_id, month
),
BalanceChanges AS (
  SELECT A.customer_id,
         ((B.balance - A.balance) / A.balance) * 100 AS balance_change_percentage
  FROM MonthlyBalances A
  JOIN MonthlyBalances B ON A.customer_id = B.customer_id AND A.month < B.month
),
IncreasedBalances AS (
  SELECT customer_id
  FROM BalanceChanges
  WHERE balance_change_percentage > 5
  GROUP BY customer_id
)
SELECT (COUNT(DISTINCT customer_id) * 100.0) / (SELECT COUNT(DISTINCT customer_id) FROM transactions) AS percentage_of_customers_increased
FROM IncreasedBalances;
